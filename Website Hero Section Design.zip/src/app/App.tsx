import { Hero } from "@/app/components/Hero";
import { ComputerScreen } from "@/app/components/ComputerScreen";
import { PhoneScreen } from "@/app/components/PhoneScreen";
import { Footer } from "@/app/components/Footer";
import { Navbar } from "@/app/components/Navbar";
import { ThemeProvider } from "@/app/components/ThemeProvider";
import { motion } from "motion/react";

export default function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen relative">
        {/* Gradient background overlay */}
        <div className="fixed inset-0 pointer-events-none z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-[var(--tooly-blue)]/5 via-[var(--tooly-orange)]/5 to-transparent"></div>
        </div>

        {/* Navbar */}
        <Navbar />

        {/* Hero Section */}
        <Hero />

        {/* Features Section - Library Demo */}
        <section
          className="py-24 px-6 md:px-12 lg:px-16 bg-background/80 backdrop-blur-sm relative z-10"
          id="library"
        >
          <div className="max-w-[1400px] mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-4xl md:text-5xl mb-6 italic font-serif">
                  Everything you need, in one place
                </h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Access hundreds of converters and calculators,
                  all completely free. From unit conversions to
                  currency exchange, temperature to time
                  zones—we've got you covered.
                </p>
                <ul className="space-y-3 text-base">
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-blue)] drop-shadow-[0_0_8px_var(--tooly-blue)]">
                      ✓
                    </span>
                    Multiple calculators and converters
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-orange)] drop-shadow-[0_0_8px_var(--tooly-orange)]">
                      ✓
                    </span>
                    100% free, forever
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-pink)] drop-shadow-[0_0_8px_var(--tooly-pink)]">
                      ✓
                    </span>
                    No sign-up required
                  </li>
                </ul>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <ComputerScreen type="library" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Dashboard Section */}
        <section
          className="py-24 px-6 md:px-12 lg:px-16 bg-muted/30 relative z-10"
          id="dashboard"
        >
          <div className="max-w-[1400px] mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-2 md:order-1"
              >
                <ComputerScreen type="dashboard" />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-1 md:order-2"
              >
                <h2 className="text-4xl md:text-5xl mb-6 italic font-serif">
                  Your personal dashboard
                </h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Create an account to save your favorite tools
                  and access them instantly. Track your
                  conversion history and customize your
                  experience.
                </p>
                <ul className="space-y-3 text-base">
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-blue)] drop-shadow-[0_0_8px_var(--tooly-blue)]">
                      ✓
                    </span>
                    Save your favorites
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-orange)] drop-shadow-[0_0_8px_var(--tooly-orange)]">
                      ✓
                    </span>
                    Conversion history
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-pink)] drop-shadow-[0_0_8px_var(--tooly-pink)]">
                      ✓
                    </span>
                    Personalized experience
                  </li>
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Mobile Section */}
        <section
          className="py-24 px-6 md:px-12 lg:px-16 bg-background/80 backdrop-blur-sm relative z-10"
          id="mobile"
        >
          <div className="max-w-[1400px] mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-4xl md:text-5xl mb-6 italic font-serif">
                  Convert on the go
                </h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Our mobile-friendly app lets you access all
                  your favorite converters anywhere, anytime.
                  Perfect for quick calculations when you're on
                  the move.
                </p>
                <ul className="space-y-3 text-base">
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-blue)] drop-shadow-[0_0_8px_var(--tooly-blue)]">
                      ✓
                    </span>
                    User-friendly mobile interface
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-orange)] drop-shadow-[0_0_8px_var(--tooly-orange)]">
                      ✓
                    </span>
                    Access anywhere, anytime
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-[var(--tooly-pink)] drop-shadow-[0_0_8px_var(--tooly-pink)]">
                      ✓
                    </span>
                    Works offline
                  </li>
                </ul>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="flex justify-center"
              >
                <PhoneScreen />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <Footer />
      </div>
    </ThemeProvider>
  );
}