import { motion, AnimatePresence } from "motion/react";
import { useState, useEffect } from "react";
import { Calculator, Ruler, DollarSign, Thermometer, Star, Heart } from "lucide-react";

interface ComputerScreenProps {
  type: "library" | "dashboard";
}

export function ComputerScreen({ type }: ComputerScreenProps) {
  const [step, setStep] = useState(0);
  
  useEffect(() => {
    const timer = setInterval(() => {
      if (type === "library") {
        setStep((prev) => (prev + 1) % 4); // 4 steps for library
      } else {
        setStep((prev) => (prev + 1) % 3); // 3 steps for dashboard
      }
    }, 2500);
    
    return () => clearInterval(timer);
  }, [type]);
  
  if (type === "library") {
    return (
      <div className="relative w-full max-w-4xl mx-auto">
        {/* Computer frame */}
        <div className="bg-gray-800 dark:bg-gray-700 rounded-t-2xl p-3 shadow-2xl border-2 border-gray-700 dark:border-gray-600">
          {/* Browser chrome */}
          <div className="bg-gray-900 dark:bg-gray-800 rounded-t-xl p-3 flex items-center gap-2">
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
            </div>
            <div className="flex-1 bg-gray-700 dark:bg-gray-700 rounded px-3 py-1 text-sm text-gray-400 ml-2">
              tooly.app/library
            </div>
          </div>
          
          {/* Screen content */}
          <div className="bg-white dark:bg-[#0A0A0A] rounded-b-xl overflow-hidden border border-gray-200 dark:border-gray-700" style={{ aspectRatio: "16/10" }}>
            <AnimatePresence mode="wait">
              {step === 0 && (
                <motion.div
                  key="browse"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full p-8"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-3xl text-gray-900 dark:text-white">Library</h2>
                    <div className="text-sm text-gray-500 dark:text-gray-400">234 tools available</div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { icon: Calculator, name: "Unit Converter", color: "bg-blue-100 dark:bg-blue-900/30 border-blue-300 dark:border-blue-700" },
                      { icon: Ruler, name: "Length Converter", color: "bg-orange-100 dark:bg-orange-900/30 border-orange-300 dark:border-orange-700" },
                      { icon: DollarSign, name: "Currency Converter", color: "bg-pink-100 dark:bg-pink-900/30 border-pink-300 dark:border-pink-700" },
                      { icon: Thermometer, name: "Temperature", color: "bg-purple-100 dark:bg-purple-900/30 border-purple-300 dark:border-purple-700" }
                    ].map((item, i) => (
                      <motion.div
                        key={item.name}
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: i * 0.1 }}
                        className={`${item.color} border-2 p-6 rounded-lg cursor-pointer hover:scale-105 transition-transform`}
                      >
                        <item.icon className="w-8 h-8 mb-2 text-gray-700 dark:text-gray-300" />
                        <p className="text-sm text-gray-900 dark:text-white">{item.name}</p>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}
              
              {step === 1 && (
                <motion.div
                  key="clicking"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full p-8 relative"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-3xl text-gray-900 dark:text-white">Library</h2>
                    <div className="text-sm text-gray-500 dark:text-gray-400">234 tools available</div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { icon: Calculator, name: "Unit Converter", color: "bg-blue-100 dark:bg-blue-900/30 border-blue-300 dark:border-blue-700", highlight: true },
                      { icon: Ruler, name: "Length Converter", color: "bg-orange-100 dark:bg-orange-900/30 border-orange-300 dark:border-orange-700" },
                      { icon: DollarSign, name: "Currency Converter", color: "bg-pink-100 dark:bg-pink-900/30 border-pink-300 dark:border-pink-700" },
                      { icon: Thermometer, name: "Temperature", color: "bg-purple-100 dark:bg-purple-900/30 border-purple-300 dark:border-purple-700" }
                    ].map((item, i) => (
                      <motion.div
                        key={item.name}
                        animate={item.highlight ? { scale: [1, 1.05, 1] } : {}}
                        transition={{ duration: 0.5 }}
                        className={`${item.color} border-2 p-6 rounded-lg cursor-pointer relative ${
                          item.highlight ? "ring-4 ring-[var(--tooly-blue)] shadow-[0_0_20px_var(--tooly-blue)]" : ""
                        }`}
                      >
                        <item.icon className="w-8 h-8 mb-2 text-gray-700 dark:text-gray-300" />
                        <p className="text-sm text-gray-900 dark:text-white">{item.name}</p>
                      </motion.div>
                    ))}
                  </div>
                  {/* Cursor indicator */}
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-32 left-32 w-6 h-6"
                  >
                    <div className="w-full h-full bg-gray-900 dark:bg-white rounded-full opacity-50"></div>
                  </motion.div>
                </motion.div>
              )}
              
              {step === 2 && (
                <motion.div
                  key="select"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="h-full p-8"
                >
                  <div className="flex items-center gap-2 mb-6">
                    <Calculator className="w-8 h-8 text-[var(--tooly-blue)]" />
                    <h2 className="text-3xl text-gray-900 dark:text-white">Unit Converter</h2>
                  </div>
                  <div className="max-w-md space-y-4">
                    <motion.div
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.2 }}
                    >
                      <label className="block text-sm mb-2 text-gray-700 dark:text-gray-300">From</label>
                      <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3 border-2 border-transparent hover:border-[var(--tooly-blue)] transition-colors">
                        <select className="w-full bg-transparent text-gray-900 dark:text-white">
                          <option>Meters</option>
                        </select>
                      </div>
                    </motion.div>
                    <motion.div
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      <label className="block text-sm mb-2 text-gray-700 dark:text-gray-300">Value</label>
                      <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3 border-2 border-[var(--tooly-blue)]">
                        <input type="text" value="1" className="w-full bg-transparent text-gray-900 dark:text-white" readOnly />
                      </div>
                    </motion.div>
                    <motion.div
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.4 }}
                    >
                      <label className="block text-sm mb-2 text-gray-700 dark:text-gray-300">To</label>
                      <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3 border-2 border-transparent hover:border-[var(--tooly-orange)] transition-colors">
                        <select className="w-full bg-transparent text-gray-900 dark:text-white">
                          <option>Feet</option>
                        </select>
                      </div>
                    </motion.div>
                  </div>
                </motion.div>
              )}
              
              {step === 3 && (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full p-8 flex items-center justify-center"
                >
                  <div className="text-center">
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.2 }}
                      className="text-7xl mb-4"
                      style={{
                        background: "linear-gradient(135deg, var(--tooly-blue), var(--tooly-orange))",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        backgroundClip: "text"
                      }}
                    >
                      3.28
                    </motion.div>
                    <p className="text-2xl text-gray-600 dark:text-gray-400">1 meter = 3.28 feet</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
        
        {/* Computer base */}
        <div className="bg-gray-300 dark:bg-gray-700 h-4 rounded-b-2xl mx-auto" style={{ width: "60%" }}></div>
        <div className="bg-gray-400 dark:bg-gray-600 h-2 rounded-full mx-auto mt-1" style={{ width: "40%" }}></div>
      </div>
    );
  }
  
  // Dashboard type with looping animations
  return (
    <div className="relative w-full max-w-4xl mx-auto">
      {/* Computer frame */}
      <div className="bg-gray-900 dark:bg-gray-950 rounded-t-2xl p-2 shadow-2xl">
        {/* Browser chrome */}
        <div className="bg-gray-800 dark:bg-gray-900 rounded-t-xl p-3 flex items-center gap-2">
          <div className="flex gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="flex-1 bg-gray-700 dark:bg-gray-800 rounded px-3 py-1 text-sm text-gray-400 ml-2">
            tooly.app/dashboard
          </div>
        </div>
        
        {/* Screen content */}
        <div className="bg-white dark:bg-[#0A0A0A] rounded-b-xl p-8" style={{ aspectRatio: "16/10" }}>
          <AnimatePresence mode="wait">
            {step === 0 && (
              <motion.div
                key="dashboard-main"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6 }}
              >
                {/* User info */}
                <motion.div className="bg-gradient-to-br from-[var(--tooly-blue)]/10 to-[var(--tooly-orange)]/10 dark:from-[var(--tooly-blue)]/20 dark:to-[var(--tooly-orange)]/20 rounded-lg p-6 shadow-sm mb-6 border border-[var(--tooly-blue)]/30">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[var(--tooly-blue)] to-[var(--tooly-orange)] flex items-center justify-center text-white text-2xl shadow-lg">
                      JD
                    </div>
                    <div>
                      <h3 className="text-xl text-gray-900 dark:text-white">John Doe</h3>
                      <p className="text-gray-600 dark:text-gray-400">john.doe@email.com</p>
                    </div>
                  </div>
                </motion.div>
                
                {/* Favorites */}
                <h3 className="text-lg mb-3 text-gray-900 dark:text-white">Your Favorites</h3>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { icon: Calculator, name: "Unit Converter", from: "from-[var(--tooly-blue)]", to: "to-blue-600" },
                    { icon: DollarSign, name: "Currency", from: "from-[var(--tooly-orange)]", to: "to-orange-600" },
                    { icon: Thermometer, name: "Temperature", from: "from-[var(--tooly-pink)]", to: "to-pink-600" }
                  ].map((item, i) => (
                    <motion.div
                      key={item.name}
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.3 + i * 0.1 }}
                      className={`bg-gradient-to-br ${item.from} ${item.to} text-white p-4 rounded-lg shadow-lg`}
                    >
                      <item.icon className="w-6 h-6 mb-2" />
                      <p className="text-sm">{item.name}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
            
            {step === 1 && (
              <motion.div
                key="hovering"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                {/* User info */}
                <div className="bg-gradient-to-br from-[var(--tooly-blue)]/10 to-[var(--tooly-orange)]/10 dark:from-[var(--tooly-blue)]/20 dark:to-[var(--tooly-orange)]/20 rounded-lg p-6 shadow-sm mb-6 border border-[var(--tooly-blue)]/30">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[var(--tooly-blue)] to-[var(--tooly-orange)] flex items-center justify-center text-white text-2xl shadow-lg">
                      JD
                    </div>
                    <div>
                      <h3 className="text-xl text-gray-900 dark:text-white">John Doe</h3>
                      <p className="text-gray-600 dark:text-gray-400">john.doe@email.com</p>
                    </div>
                  </div>
                </div>
                
                {/* Favorites with hover effect */}
                <h3 className="text-lg mb-3 text-gray-900 dark:text-white">Your Favorites</h3>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { icon: Calculator, name: "Unit Converter", from: "from-[var(--tooly-blue)]", to: "to-blue-600", highlight: true },
                    { icon: DollarSign, name: "Currency", from: "from-[var(--tooly-orange)]", to: "to-orange-600" },
                    { icon: Thermometer, name: "Temperature", from: "from-[var(--tooly-pink)]", to: "to-pink-600" }
                  ].map((item, i) => (
                    <motion.div
                      key={item.name}
                      animate={item.highlight ? {
                        scale: [1, 1.05, 1],
                        boxShadow: [
                          "0 10px 15px -3px rgba(96, 165, 250, 0.3)",
                          "0 20px 25px -5px rgba(96, 165, 250, 0.5), 0 0 30px rgba(96, 165, 250, 0.4)",
                          "0 10px 15px -3px rgba(96, 165, 250, 0.3)"
                        ]
                      } : {}}
                      transition={{ duration: 0.6 }}
                      className={`bg-gradient-to-br ${item.from} ${item.to} text-white p-4 rounded-lg shadow-lg relative`}
                    >
                      <item.icon className="w-6 h-6 mb-2" />
                      <p className="text-sm">{item.name}</p>
                      {item.highlight && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute -top-1 -right-1"
                        >
                          <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
                        </motion.div>
                      )}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
            
            {step === 2 && (
              <motion.div
                key="clicked"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="h-full flex items-center justify-center"
              >
                <div className="text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", duration: 0.6 }}
                  >
                    <Heart className="w-24 h-24 mx-auto mb-4 fill-[var(--tooly-pink)] text-[var(--tooly-pink)]" />
                  </motion.div>
                  <motion.h3
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="text-3xl mb-2 text-gray-900 dark:text-white"
                  >
                    Added to Favorites!
                  </motion.h3>
                  <p className="text-gray-600 dark:text-gray-400">Unit Converter saved</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
      
      {/* Computer base */}
      <div className="bg-gray-300 dark:bg-gray-700 h-4 rounded-b-2xl mx-auto" style={{ width: "60%" }}></div>
      <div className="bg-gray-400 dark:bg-gray-600 h-2 rounded-full mx-auto mt-1" style={{ width: "40%" }}></div>
    </div>
  );
}