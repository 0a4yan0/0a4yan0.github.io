import { motion, useInView } from "motion/react";
import { ArrowRight, Zap, MessageSquarePlus, Users, Sparkles } from "lucide-react";
import { useState, useEffect, useRef } from "react";

const fullText = "The answer to all your questions.";

export function Hero() {
  const [displayedText, setDisplayedText] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(heroRef, { once: false, amount: 0.5 });

  useEffect(() => {
    if (isInView) {
      // Reset and start typewriter effect
      setDisplayedText("");
      setCurrentIndex(0);
    }
  }, [isInView]);

  useEffect(() => {
    if (isInView && currentIndex < fullText.length) {
      const timeout = setTimeout(() => {
        setDisplayedText((prev) => prev + fullText[currentIndex]);
        setCurrentIndex((prev) => prev + 1);
      }, 50); // Faster typewriter effect

      return () => clearTimeout(timeout);
    }
  }, [currentIndex, isInView]);

  const features = [
    {
      icon: Zap,
      title: "Easy-to-access",
      description: "All tools at your fingertips, organized and ready to use"
    },
    {
      icon: MessageSquarePlus,
      title: "Request Tools",
      description: "Need a specific calculator? Just ask and we'll build it"
    },
    {
      icon: Users,
      title: "Built by Users",
      description: "Features come from real requests rather than trends"
    },
    {
      icon: Sparkles,
      title: "Exclusive Access",
      description: "Beta tools that will soon launch in the main app"
    }
  ];

  return (
    <div
      ref={heroRef}
      className="min-h-screen flex items-center bg-background pt-20 px-6 md:px-12 lg:px-16"
    >
      <div className="max-w-[1400px] mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Hero content */}
          <div className="max-w-2xl">
            {/* Main heading with typewriter effect */}
            <h1 className="text-5xl md:text-7xl mb-6 italic font-serif">
              {displayedText}
              <motion.span
                animate={{ opacity: [1, 0] }}
                transition={{ duration: 0.8, repeat: Infinity, repeatType: "reverse" }}
                className="inline-block w-1 h-12 md:h-20 bg-foreground ml-1 align-middle"
              />
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
              All of the calculators, converters, and tools you'll ever need, in one
              easy-to-access place.
            </p>

            {/* Email signup */}
            <div className="flex flex-col gap-3 max-w-xl">
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  placeholder="Enter your email address here"
                  className="flex-1 px-5 py-3 text-sm rounded-lg bg-input-background dark:bg-white/5 border border-border focus:outline-none focus:ring-2 focus:ring-[var(--tooly-blue)] transition-all"
                />
                <button className="group px-6 py-3 text-sm rounded-lg bg-gradient-to-r from-[var(--tooly-blue)] via-[var(--tooly-orange)] to-[var(--tooly-pink)] text-white font-medium flex items-center justify-center gap-2 transition-all hover:opacity-90 hover:scale-105">
                  Get Notified
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
              <p className="text-xs text-muted-foreground">
                Get notified when Tooly launches. No spam, unsubscribe any time.
              </p>
            </div>
          </div>

          {/* Right side - Feature boxes */}
          <div className="grid grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
                className={`bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 ${
                  index === 3 ? "bg-gradient-to-br from-[var(--tooly-orange)] to-[var(--tooly-pink)] text-white border-transparent" : ""
                }`}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-4 ${
                  index === 3 
                    ? "bg-white/20" 
                    : "bg-gradient-to-br from-[var(--tooly-blue)]/10 to-[var(--tooly-orange)]/10"
                }`}>
                  <feature.icon className={`w-5 h-5 ${
                    index === 3 ? "text-white" : "text-[var(--tooly-orange)]"
                  }`} />
                </div>
                <h3 className={`text-base font-semibold mb-2 ${
                  index === 3 ? "text-white" : "text-gray-900 dark:text-white"
                }`}>
                  {feature.title}
                </h3>
                <p className={`text-xs ${
                  index === 3 ? "text-white/80" : "text-gray-600 dark:text-gray-400"
                }`}>
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}