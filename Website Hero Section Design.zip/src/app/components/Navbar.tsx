import { Wrench, Moon, Sun, LayoutDashboard, Library, User } from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";

export function Navbar() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [hoveredLink, setHoveredLink] = useState<string | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  const navLinks = [
    { href: "#dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "#library", label: "Browse Library", icon: Library },
    { href: "#profile", label: "My Profile", icon: User }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-white/70 dark:bg-black/70 border-b border-gray-200/50 dark:border-gray-800/50">
      <div className="max-w-[1400px] mx-auto px-6 md:px-12 lg:px-16 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and brand */}
          <div className="flex items-center gap-2">
            <Wrench className="w-6 h-6 text-foreground" />
            <span className="text-xl font-bold">Tooly</span>
          </div>

          {/* Navigation links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onMouseEnter={() => setHoveredLink(link.label)}
                onMouseLeave={() => setHoveredLink(null)}
                className="flex items-center gap-2 text-sm transition-all duration-300 group"
                style={{
                  background: hoveredLink === link.label 
                    ? "linear-gradient(90deg, var(--tooly-blue), var(--tooly-orange), var(--tooly-pink))"
                    : "transparent",
                  WebkitBackgroundClip: hoveredLink === link.label ? "text" : "unset",
                  WebkitTextFillColor: hoveredLink === link.label ? "transparent" : "inherit",
                  backgroundClip: hoveredLink === link.label ? "text" : "unset"
                }}
              >
                {hoveredLink === link.label && (
                  <link.icon className="w-4 h-4" style={{
                    background: "linear-gradient(90deg, var(--tooly-blue), var(--tooly-orange), var(--tooly-pink))",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text"
                  }} />
                )}
                {link.label}
              </a>
            ))}
          </div>

          {/* Theme toggle */}
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="p-2 rounded-lg bg-foreground/5 hover:bg-foreground/10 transition-all"
            aria-label="Toggle theme"
          >
            {mounted && theme === "dark" ? (
              <Sun className="w-5 h-5" />
            ) : (
              <Moon className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>
    </nav>
  );
}