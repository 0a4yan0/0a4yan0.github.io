import { motion, AnimatePresence } from "motion/react";
import { Calculator, DollarSign, Thermometer, Ruler, ArrowLeft, Check } from "lucide-react";
import { useState, useEffect } from "react";

export function PhoneScreen() {
  const [step, setStep] = useState(0);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setStep((prev) => (prev + 1) % 3); // 3 steps for mobile
    }, 2500);
    
    return () => clearInterval(timer);
  }, []);
  
  return (
    <div className="relative w-full max-w-xs mx-auto">
      {/* Phone frame */}
      <div className="bg-gray-900 dark:bg-black rounded-[3rem] p-3 shadow-2xl">
        {/* Notch */}
        <div className="bg-gray-900 dark:bg-black h-6 w-32 mx-auto rounded-b-2xl absolute top-3 left-1/2 -translate-x-1/2 z-10"></div>
        
        {/* Screen */}
        <div className="bg-white dark:bg-[#0A0A0A] rounded-[2.5rem] overflow-hidden" style={{ aspectRatio: "9/19.5" }}>
          <div className="h-full">
            <AnimatePresence mode="wait">
              {step === 0 && (
                <motion.div
                  key="phone-list"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="h-full bg-white dark:bg-[#0A0A0A] p-6"
                >
                  {/* Status bar */}
                  <div className="flex justify-between items-center mb-8 pt-6 text-gray-900 dark:text-white">
                    <span className="text-sm">9:41</span>
                    <div className="flex gap-1 items-center text-xs">
                      <span>📶</span>
                      <span>🔋</span>
                    </div>
                  </div>
                  
                  {/* App content */}
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    <h2 className="text-2xl mb-6 text-gray-900 dark:text-white">Converters</h2>
                    
                    <div className="space-y-3">
                      {[
                        { icon: Calculator, name: "Unit Converter", color: "bg-[var(--tooly-blue)]" },
                        { icon: DollarSign, name: "Currency", color: "bg-[var(--tooly-orange)]" },
                        { icon: Thermometer, name: "Temperature", color: "bg-[var(--tooly-pink)]" },
                        { icon: Ruler, name: "Length", color: "bg-purple-500" }
                      ].map((item, i) => (
                        <motion.div
                          key={item.name}
                          initial={{ x: -20, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.3 + i * 0.1 }}
                          className="bg-gray-50 dark:bg-gray-900 rounded-2xl p-4 shadow-sm flex items-center gap-3 border border-gray-200 dark:border-gray-800"
                        >
                          <div className={`${item.color} w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-lg`}>
                            <item.icon className="w-6 h-6" />
                          </div>
                          <span className="text-gray-900 dark:text-white">{item.name}</span>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                </motion.div>
              )}
              
              {step === 1 && (
                <motion.div
                  key="phone-converter"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="h-full bg-white dark:bg-[#0A0A0A] p-6"
                >
                  {/* Status bar */}
                  <div className="flex justify-between items-center mb-8 pt-6 text-gray-900 dark:text-white">
                    <span className="text-sm">9:41</span>
                    <div className="flex gap-1 items-center text-xs">
                      <span>📶</span>
                      <span>🔋</span>
                    </div>
                  </div>
                  
                  {/* Header */}
                  <motion.div
                    initial={{ y: -20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="flex items-center gap-3 mb-6"
                  >
                    <ArrowLeft className="w-6 h-6 text-gray-900 dark:text-white" />
                    <h2 className="text-2xl text-gray-900 dark:text-white">Unit Converter</h2>
                  </motion.div>
                  
                  {/* Converter content */}
                  <div className="space-y-4">
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.2 }}
                      className="bg-gradient-to-br from-[var(--tooly-blue)]/10 to-[var(--tooly-orange)]/10 dark:from-[var(--tooly-blue)]/20 dark:to-[var(--tooly-orange)]/20 border-2 border-[var(--tooly-blue)]/30 rounded-2xl p-4"
                    >
                      <label className="text-xs text-gray-600 dark:text-gray-400 mb-2 block">From</label>
                      <div className="text-3xl text-gray-900 dark:text-white mb-1">100</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Meters</div>
                    </motion.div>
                    
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1, rotate: 90 }}
                      transition={{ delay: 0.4, type: "spring" }}
                      className="w-10 h-10 mx-auto bg-gradient-to-br from-[var(--tooly-blue)] to-[var(--tooly-orange)] rounded-full flex items-center justify-center text-white shadow-lg"
                    >
                      <span className="text-xl">⇄</span>
                    </motion.div>
                    
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.3 }}
                      className="bg-gradient-to-br from-[var(--tooly-orange)]/10 to-[var(--tooly-pink)]/10 dark:from-[var(--tooly-orange)]/20 dark:to-[var(--tooly-pink)]/20 border-2 border-[var(--tooly-orange)]/30 rounded-2xl p-4"
                    >
                      <label className="text-xs text-gray-600 dark:text-gray-400 mb-2 block">To</label>
                      <div className="text-3xl text-gray-900 dark:text-white mb-1">328.08</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Feet</div>
                    </motion.div>
                  </div>
                </motion.div>
              )}
              
              {step === 2 && (
                <motion.div
                  key="phone-success"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full bg-gradient-to-br from-[var(--tooly-blue)]/20 to-[var(--tooly-orange)]/20 dark:from-[var(--tooly-blue)]/10 dark:to-[var(--tooly-orange)]/10 p-6 flex items-center justify-center"
                >
                  <div className="text-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", duration: 0.6 }}
                      className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-[var(--tooly-blue)] to-[var(--tooly-orange)] flex items-center justify-center shadow-2xl"
                    >
                      <Check className="w-12 h-12 text-white" />
                    </motion.div>
                    <motion.h3
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.3 }}
                      className="text-2xl mb-2 text-gray-900 dark:text-white"
                    >
                      Converted!
                    </motion.h3>
                    <p className="text-gray-600 dark:text-gray-400">100m = 328.08ft</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
      
      {/* Button shadows */}
      <div className="absolute right-0 top-24 w-1 h-12 bg-gray-800 dark:bg-gray-950 rounded-l"></div>
      <div className="absolute right-0 top-40 w-1 h-16 bg-gray-800 dark:bg-gray-950 rounded-l"></div>
      <div className="absolute left-0 top-32 w-1 h-8 bg-gray-800 dark:bg-gray-950 rounded-r"></div>
    </div>
  );
}
