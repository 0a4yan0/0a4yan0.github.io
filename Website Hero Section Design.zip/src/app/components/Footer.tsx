import { 
  Library, 
  Mail, 
  FileText, 
  LayoutDashboard, 
  LogIn, 
  UserPlus, 
  Shield,
  Book,
  Lock,
  FileCheck,
  MessageCircle,
  Instagram,
  Send,
  Hash
} from "lucide-react";
import { useState } from "react";

export function Footer() {
  const [hoveredLink, setHoveredLink] = useState<string | null>(null);

  const footerSections = [
    {
      title: "Product",
      links: [
        { name: "Library", href: "#library", icon: Library },
        { name: "Contact", href: "#contact", icon: MessageCircle },
        { name: "About", href: "#about", icon: FileText }
      ]
    },
    {
      title: "Resources",
      links: [
        { name: "Documentation", href: "#docs", icon: Book },
        { name: "Privacy Policy", href: "#privacy", icon: Lock },
        { name: "Terms of Service", href: "#terms", icon: FileCheck }
      ]
    },
    {
      title: "Developer Tools",
      links: [
        { name: "Dashboard", href: "#dashboard", icon: LayoutDashboard },
        { name: "Login", href: "#login", icon: LogIn },
        { name: "Sign Up", href: "#signup", icon: UserPlus },
        { name: "Administrator Panel", href: "#admin", icon: Shield }
      ]
    }
  ];

  const socials = [
    { name: "Discord", icon: Hash, href: "#discord", color: "#5865F2" },
    { name: "Instagram", icon: Instagram, href: "#instagram", color: "#E4405F" },
    { name: "TikTok", icon: Send, href: "#tiktok", color: "#000000" },
    { name: "Email", icon: Mail, href: "mailto:hello@tooly.app", color: "#EA4335" }
  ];
  
  return (
    <footer className="bg-gray-900 dark:bg-black text-gray-300 py-16 border-t border-gray-800">
      <div className="max-w-[1400px] mx-auto px-6 md:px-12 lg:px-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand column */}
          <div className="lg:col-span-1">
            <h3 className="text-2xl font-bold text-white mb-4">Tooly</h3>
            <p className="text-sm text-gray-400 mb-6">
              Connecting tool enthusiasts. Plan, build, and shift into gear with the ultimate productivity platform.
            </p>
            
            {/* Social icons */}
            <div className="flex gap-3">
              {socials.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  className="w-10 h-10 rounded-lg bg-gradient-to-br from-[var(--tooly-blue)]/20 to-[var(--tooly-orange)]/20 hover:from-[var(--tooly-blue)] hover:to-[var(--tooly-orange)] flex items-center justify-center transition-all hover:scale-110"
                  aria-label={social.name}
                >
                  <social.icon className="w-5 h-5 text-white" />
                </a>
              ))}
            </div>
          </div>
          
          {/* Links columns */}
          {footerSections.map((section) => (
            <div key={section.title}>
              <h4 className="text-[var(--tooly-orange)] font-semibold mb-4 text-sm">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <a 
                      href={link.href}
                      onMouseEnter={() => setHoveredLink(link.name)}
                      onMouseLeave={() => setHoveredLink(null)}
                      className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm group"
                    >
                      {hoveredLink === link.name && (
                        <link.icon className="w-4 h-4 transition-all" style={{
                          background: "linear-gradient(90deg, var(--tooly-blue), var(--tooly-orange), var(--tooly-pink))",
                          WebkitBackgroundClip: "text",
                          WebkitTextFillColor: "transparent",
                          backgroundClip: "text"
                        }} />
                      )}
                      <span style={{
                        background: hoveredLink === link.name 
                          ? "linear-gradient(90deg, var(--tooly-blue), var(--tooly-orange), var(--tooly-pink))"
                          : "transparent",
                        WebkitBackgroundClip: hoveredLink === link.name ? "text" : "unset",
                        WebkitTextFillColor: hoveredLink === link.name ? "transparent" : "inherit",
                        backgroundClip: hoveredLink === link.name ? "text" : "unset"
                      }}>
                        {link.name}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter section */}
        <div className="bg-gradient-to-r from-[var(--tooly-orange)]/10 to-[var(--tooly-pink)]/10 border border-[var(--tooly-orange)]/30 rounded-2xl p-8 mb-8">
          <div className="max-w-2xl mx-auto text-center">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Mail className="w-5 h-5 text-[var(--tooly-orange)]" />
              <h3 className="text-xl font-semibold text-white">Stay Updated</h3>
            </div>
            <p className="text-gray-400 text-sm mb-6">
              Get the latest updates on Tooly launches, features, and productivity tips.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-5 py-3 text-sm rounded-lg bg-gray-800 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-[var(--tooly-orange)] transition-all"
              />
              <button className="px-6 py-3 text-sm rounded-lg bg-gradient-to-r from-[var(--tooly-orange)] to-[var(--tooly-pink)] text-white font-medium hover:opacity-90 transition-all">
                Join the Waitlist →
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500">
          <p>© 2026 Tooly by Repple. All rights reserved.</p>
          <div className="flex items-center gap-2">
            <span className="text-red-500">❤️</span>
            <span>Made with passion for tool enthusiasts</span>
          </div>
          <div className="flex gap-4 text-xs">
            <a href="#community" className="hover:text-white transition-colors">
              🌍 Global Community
            </a>
            <span>•</span>
            <a href="#est" className="hover:text-white transition-colors">
              Est. 2025
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
